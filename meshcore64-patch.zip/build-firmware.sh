#!/usr/bin/env bash
# Build the MeshCore 64 companion firmware for the Heltec V3 cartridge.
#
# Usage:  ./build-firmware.sh [/path/to/meshcore]     (defaults to cwd)
#
# Run this from inside the patched MeshCore checkout, after apply-patch.sh.
#
# Deliberately does NOT use the repo's build.sh, because that appends
# "-<commit>" to the version string -- and the OLED splash screen truncates
# the version at the first dash (ui-new/UITask.cpp: "strip off dash and
# commit hash"), so anything after a dash never reaches the display. We set
# the version exactly and put the commit in the FILENAME instead.
#
# The version is derived from MeshCore's own FIRMWARE_VERSION in
# examples/companion_radio/MyMesh.h, so it tracks upstream automatically
# rather than being hardcoded.
set -euo pipefail

# Take the checkout as an argument (or use cwd) rather than assuming this
# script lives inside it -- it ships in a zip and gets unpacked anywhere.
TARGET="${1:-$PWD}"
cd "$TARGET"

if [ ! -f examples/companion_radio/MyMesh.h ]; then
  echo "error: '$TARGET' does not look like a MeshCore checkout" >&2
  echo "usage: build-firmware.sh [/path/to/meshcore]" >&2
  exit 1
fi

ENV_NAME="Heltec_v3_companion_radio_usb"

# upstream MeshCore version, e.g. v1.17.1
MESHCORE_VER="$(sed -n 's/^#define FIRMWARE_VERSION "\(.*\)"/\1/p' \
                examples/companion_radio/MyMesh.h | head -1)"
if [ -z "$MESHCORE_VER" ]; then
  echo "could not read FIRMWARE_VERSION from MyMesh.h" >&2
  exit 1
fi

# The OLED splash stores the version in a 12-byte buffer (ui-new/UITask.cpp:
# "char _version_info[12]") and truncates it at the first dash, so the name
# has to fit in 11 characters and must not contain a dash. "mc64 1.17.1" is
# exactly 11. Keeping the name short avoids having to patch the firmware's
# UI code, so the firmware diff stays limited to the serial/UART changes.
VERSION="mc64 ${MESHCORE_VER#v}"
COMMIT="$(git rev-parse --short HEAD 2>/dev/null || echo nogit)"
BUILD_DATE="$(date '+%d %b %Y')"
STEM="meshcore64-${MESHCORE_VER#v}-${COMMIT}"
OUT="${OUT_DIR:-$PWD/meshcore64-build}"

echo "==> MeshCore version : ${MESHCORE_VER}"
echo "==> Reported version : ${VERSION}   (shown in the C64 app and on the OLED)"
echo "==> Commit           : ${COMMIT}"

PIPX_BIN="$(pipx environment --value PIPX_BIN_DIR 2>/dev/null || echo "$HOME/.local/bin")"
export PATH="$PIPX_BIN:$PATH"

export PLATFORMIO_BUILD_FLAGS="-DFIRMWARE_VERSION='\"${VERSION}\"' -DFIRMWARE_BUILD_DATE='\"${BUILD_DATE}\"'"

mkdir -p "$OUT"
pio run -e "$ENV_NAME" -t mergebin

cp ".pio/build/${ENV_NAME}/firmware.bin"        "${OUT}/${STEM}.bin"
cp ".pio/build/${ENV_NAME}/firmware-merged.bin" "${OUT}/${STEM}-merged.bin"

echo
echo "Built:"
echo "  ${OUT}/${STEM}-merged.bin   (full flash @ 0x0 - use this for a fresh flash)"
echo "  ${OUT}/${STEM}.bin          (app only - for OTA-style updates)"
