#!/usr/bin/env bash
# Apply the meshcore64 serial/IO patch to a MeshCore checkout.
#
# Usage:  ./apply-patch.sh [/path/to/meshcore]     (defaults to cwd)
#
# The patch only touches the C64 cart's serial link:
#   examples/companion_radio/main.cpp   - configurable UART number + baud,
#                                         and pins passed into begin()
#   variants/heltec_v3/platformio.ini   - SERIAL_RX/TX, baud, UART number
#
# It does NOT touch the radio/region settings in the top-level
# platformio.ini (LORA_FREQ, LORA_SF, ...) - those are yours to set per
# deployment and are independent of this integration.
set -euo pipefail

PATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/meshcore64-serial-io.patch"
TARGET="${1:-$PWD}"
cd "$TARGET"

if [ ! -f examples/companion_radio/main.cpp ]; then
  echo "error: '$TARGET' does not look like a MeshCore checkout" >&2
  exit 1
fi

echo "==> target : $TARGET"
echo "==> patch  : $PATCH"

# Is it already applied?
if git apply --reverse --check "$PATCH" 2>/dev/null; then
  echo "Patch is already applied - nothing to do."
  exit 0
fi

# Clean apply?
if git apply --check "$PATCH" 2>/dev/null; then
  git apply "$PATCH"
  echo "Applied cleanly."
else
  echo "Context has moved upstream; retrying with fuzz (3-way merge)..."
  if git apply --3way "$PATCH"; then
    echo "Applied with a 3-way merge - please review the result."
  else
    cat >&2 <<'EOF'

Automatic apply failed. The patch is small and easy to redo by hand -
these are the only changes needed:

  examples/companion_radio/main.cpp
    1. Make the UART number configurable (the Heltec V3 cart needs UART2;
       the code hardcodes 1, which silently receives nothing on this board):
         #ifndef HW_SERIAL_UART_NUM
           #define HW_SERIAL_UART_NUM 1
         #endif
         HardwareSerial companion_serial(HW_SERIAL_UART_NUM);

    2. Add a separate baud for that UART (the C64 link runs at 600, while
       USB stays at 115200):
         #ifndef HW_SERIAL_BAUD_RATE
           #define HW_SERIAL_BAUD_RATE 115200
         #endif

    3. Pass the pins straight into begin() instead of a separate setPins()
       call, and use the new baud:
         companion_serial.begin(HW_SERIAL_BAUD_RATE, SERIAL_8N1,
                                SERIAL_RX, SERIAL_TX);

  variants/heltec_v3/platformio.ini
    Add to the [env:Heltec_v3_companion_radio_usb] build_flags:
         -D SERIAL_RX=45
         -D SERIAL_TX=46
         -D HW_SERIAL_BAUD_RATE=600
         -D HW_SERIAL_UART_NUM=2

EOF
    exit 1
  fi
fi

echo
echo "Next: build with deliverables/build-firmware.sh"
